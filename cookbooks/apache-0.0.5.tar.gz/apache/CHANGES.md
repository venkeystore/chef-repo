# 0.0.3
- ssl support
- start_service attribute

# 0.0.4
- bug fix for apache log dir

# 0.0.5
- add security patch (http://www.opennet.ru/opennews/art.shtml?num=31582)
